-- UTL-Add-on-Teile (Wiki „Add-ons: Fenster“): Abschnitt „TouchDeck“ im Stationsfenster (Station auf
-- einen Platz 1–8 des TouchDeck heften) und Reiter „TouchDeck“ im UTL-Manager (angeheftete Stationen).
-- UTL legt den Platz an und ruft die Bau-Funktionen über unsere Schnittstelle auf; Eingaben behandeln wir
-- selbst (on_gui_checked_state_changed, on_gui_selection_state_changed, on_gui_click).
local Utl = require("scripts.utl")

local UtlGui = {}

local PIN = "tdb_utl_pin"
local SLOT = "tdb_utl_slot"
local UNPIN = "tdb_utl_unpin"

local function slot_items()
  local items = {}
  for i = 1, Utl.PIN_SLOTS do
    items[i] = { "touchdeck-bridge.utl-slot", i }
  end
  return items
end

--- Erster freier Platz des Teams (sonst 1).
local function free_slot(force_name)
  local used = {}
  for _, p in ipairs(Utl.pinned(force_name)) do used[p.slot] = true end
  for i = 1, Utl.PIN_SLOTS do
    if not used[i] then return i end
  end
  return 1
end

local function surface_caption(index)
  local surface = game.get_surface(index)
  if not surface then return "?" end
  if surface.platform then return surface.platform.name end
  if surface.planet then return surface.planet.prototype.localised_name end
  return surface.localised_name or surface.name
end

--- Abschnitt im Stationsfenster (UTL ruft das beim Öffnen und Neuaufbau).
---@param flow LuaGuiElement
---@param unit uint32
---@param player_index uint32
function UtlGui.section(flow, unit, player_index)
  local player = game.get_player(player_index)
  if not (player and flow.valid) then return end
  local slot = Utl.pin_of(unit)
  flow.add({ type = "label", caption = { "touchdeck-bridge.utl-section" }, style = "caption_label" })
  local row = flow.add({ type = "flow", direction = "horizontal" })
  row.style.vertical_align = "center"
  row.style.horizontal_spacing = 8
  row.add({ type = "checkbox", name = PIN, state = slot ~= nil, caption = { "touchdeck-bridge.utl-pin" },
    tooltip = { "touchdeck-bridge.utl-pin-tooltip" }, tags = { tdb_station = unit } })
  row.add({ type = "drop-down", name = SLOT, items = slot_items(),
    selected_index = slot or free_slot(player.force.name), tags = { tdb_station = unit } })
end

--- Reiter im UTL-Manager (UTL ruft das beim Wählen des Reiters und bei ⟲).
---@param flow LuaGuiElement
---@param player_index uint32
function UtlGui.tab(flow, player_index)
  local player = game.get_player(player_index)
  if not (player and flow.valid) then return end
  flow.add({ type = "label", caption = { "touchdeck-bridge.utl-tab-hint" } }).style.single_line = false
  local pinned = Utl.pinned(player.force.name)
  if #pinned == 0 then
    flow.add({ type = "label", caption = { "touchdeck-bridge.utl-tab-empty" } })
    return
  end
  local list = flow.add({ type = "table", column_count = 5, draw_horizontal_lines = true })
  list.style.horizontal_spacing = 16
  for _, key in ipairs({ "slot", "station", "surface", "network", "action" }) do
    list.add({ type = "label", caption = { "touchdeck-bridge.utl-col-" .. key }, style = "caption_label" })
  end
  for _, p in ipairs(pinned) do
    local info = Utl.call("get_station", p.unit)
    list.add({ type = "label", caption = tostring(p.slot) })
    list.add({ type = "label", caption = type(info) == "table" and info.stop_name or "?" })
    list.add({ type = "label", caption = surface_caption(p.surface) })
    list.add({ type = "label", caption = p.network or "–" })
    list.add({ type = "button", name = UNPIN .. "_" .. p.unit, caption = { "touchdeck-bridge.utl-unpin" },
      tags = { tdb_unpin = p.unit } })
  end
end

-- ---------------------------------------------------------------- Eingaben

---@param event EventData.on_gui_checked_state_changed
function UtlGui.on_checked(event)
  local element = event.element
  if not (element and element.valid and element.name == PIN) then return end
  local unit = element.tags.tdb_station --[[@as uint32]]
  local dropdown = element.parent and element.parent[SLOT]
  local slot = dropdown and dropdown.selected_index or 1
  Utl.pin(unit, element.state and slot or nil)
end

---@param event EventData.on_gui_selection_state_changed
function UtlGui.on_selected(event)
  local element = event.element
  if not (element and element.valid and element.name == SLOT) then return end
  local checkbox = element.parent and element.parent[PIN]
  if checkbox and checkbox.state then
    Utl.pin(element.tags.tdb_station --[[@as uint32]], element.selected_index)
  end
end

---@param event EventData.on_gui_click
function UtlGui.on_click(event)
  local element = event.element
  if not (element and element.valid and element.tags and element.tags.tdb_unpin) then return end
  Utl.pin(element.tags.tdb_unpin --[[@as uint32]], nil)
  -- Reiter neu aufbauen: Tabelle → Inhalt des Reiters
  local tab = element.parent and element.parent.parent
  if tab and tab.valid then
    tab.clear()
    UtlGui.tab(tab, event.player_index)
  end
end

return UtlGui
