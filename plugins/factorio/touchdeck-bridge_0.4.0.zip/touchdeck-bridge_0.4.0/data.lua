require("prototypes.inputs")
