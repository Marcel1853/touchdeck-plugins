-- Optional: Daten aus dem Mod „UTLogistics“ über seine Schnittstelle „utl“ (Wiki „Für Mod-Autoren“).
-- Kein Muss: Fehlt der Mod oder eine Funktion/ein Ereignis, wird das übersprungen (Aufrufe in pcall).
-- Kein Add-on (keine Rollen, Fahrten, Fenster) – nur lesen, so wie das Wiki es empfiehlt:
--   * billige Zähler (station_count, idle_train_count, delivery_count) im Takt,
--   * Listen und Statistik nicht im Takt: Netze nur nach Stations-Ereignissen neu, Statistik alle 5 min,
--   * alles andere aus Ereignissen mitzählen (Lieferungen, Waren pro Stunde, Warnungen, Anfragen ohne Zug).
-- Ereignisse werden in on_init und on_load angemeldet (IDs entstehen bei jedem Laden neu).
local Utl = {}

local MOD = "UTLogistics"
local STATS_TICKS = 18000      -- get_statistics (nur für die Auslastung) höchstens alle 5 Minuten
local MINUTE = 3600
local HOUR_MINUTES = 60
local ALERTS_KEPT = 5
local UNSERVED_TTL = 3 * MINUTE  -- UTL meldet eine wartende Anfrage höchstens einmal pro Minute
local TOP_GOODS = 8

function Utl.available()
  return script.active_mods[MOD] ~= nil and remote.interfaces["utl"] ~= nil
end

--- Funktion der Schnittstelle aufrufen; nil, wenn es sie nicht gibt oder sie einen Fehler wirft.
local function call(name, ...)
  local api = remote.interfaces["utl"]
  if not (api and api[name]) then return nil end
  local ok, result = pcall(remote.call, "utl", name, ...)
  if ok then return result end
  return nil
end

-- ---------------------------------------------------------------- Speicher (storage.utl)

local function data()
  storage.utl = storage.utl or {}
  local d = storage.utl
  d.minutes = d.minutes or {}     -- [Minute] = { count, goods = { [Waren-Schlüssel] = Menge } }
  d.alerts = d.alerts or {}       -- [Force-Name] = { { tick, icon, group, message, surface }, … } neueste zuerst
  d.unserved = d.unserved or {}   -- ["station|key"] = { key, network, since, reason, tick }
  d.networks = d.networks or {}   -- ["force:surface"] = Anzahl (leer = neu holen)
  d.total = d.total or 0          -- abgeschlossene Lieferungen, seit touchdeck-bridge mitzählt
  return d
end

-- ---------------------------------------------------------------- Ereignisse

local function on_completed(event)
  local d = data()
  local minute = math.floor(event.tick / MINUTE)
  local bucket = d.minutes[minute]
  if not bucket then
    bucket = { count = 0, goods = {} }
    d.minutes[minute] = bucket
    for m in pairs(d.minutes) do
      if m <= minute - HOUR_MINUTES then d.minutes[m] = nil end
    end
  end
  bucket.count = bucket.count + 1
  d.total = d.total + 1
  if type(event.manifest) == "table" then
    for key, amount in pairs(event.manifest) do
      if type(amount) == "number" then bucket.goods[key] = (bucket.goods[key] or 0) + amount end
    end
  end
end

local function on_alert(event)
  local d = data()
  local force = type(event.force) == "string" and event.force or "player"
  local list = d.alerts[force] or {}
  table.insert(list, 1, { tick = event.tick, icon = event.icon, group = event.group, message = event.message,
    surface = event.surface })
  for i = #list, ALERTS_KEPT + 1, -1 do
    list[i] = nil
  end
  d.alerts[force] = list
end

local function on_unserved(event)
  local d = data()
  if event.station == nil or event.key == nil then return end
  d.unserved[tostring(event.station) .. "|" .. tostring(event.key)] = {
    key = event.key, network = event.network, since = event.since, reason = event.reason, tick = event.tick,
  }
end

local function on_station_event()
  data().networks = {}
end

--- In on_init und on_load aufrufen. Meldet nur Ereignisse an, die die installierte UTL-Version kennt.
function Utl.listen()
  if not Utl.available() or not remote.interfaces["utl"].get_event_ids then return end
  local ok, ids = pcall(remote.call, "utl", "get_event_ids")
  if not (ok and type(ids) == "table") then return end
  local handlers = {
    on_delivery_completed = on_completed,
    on_alert = on_alert,
    on_request_unserved = on_unserved,
    on_station_created = on_station_event,
    on_station_changed = on_station_event,
    on_station_removed = on_station_event,
  }
  for name, handler in pairs(handlers) do
    if ids[name] then script.on_event(ids[name], handler) end
  end
end

-- ---------------------------------------------------------------- Lesen

--- Zustand für Team und Fläche. Billig: Zähler und eigener Speicher; Netze und Statistik nur selten.
---@param force LuaForce
---@param surface LuaSurface
function Utl.read(force, surface)
  if not Utl.available() then
    return { active = false }
  end
  local d = data()
  local out = {
    active = true,
    version = script.active_mods[MOD],
    api = call("api_version"),
    idle = call("idle_train_count"),
    deliveries = call("delivery_count"),
    stations = call("station_count"),
    total = d.total,
  }

  local place = force.index .. ":" .. surface.index
  if d.networks[place] == nil then
    local list = call("get_networks", surface.index, force.name)
    d.networks[place] = type(list) == "table" and #list or false
  end
  out.networks = d.networks[place] or nil

  if not d.stats_tick or game.tick - d.stats_tick >= STATS_TICKS then
    d.stats_tick = game.tick
    local stats = call("get_statistics")
    d.utilization = nil
    if type(stats) == "table" then
      local sum, n = 0, 0
      for _, t in pairs(type(stats.trains) == "table" and stats.trains or {}) do
        if type(t.utilization) == "number" then sum, n = sum + t.utilization, n + 1 end
      end
      d.utilization = n > 0 and sum / n or nil
    end
  end
  out.utilization = d.utilization

  -- Lieferungen und Waren der letzten Stunde (aus on_delivery_completed)
  local now = math.floor(game.tick / MINUTE)
  local hour, goods = 0, {}
  for minute, bucket in pairs(d.minutes) do
    if minute > now - HOUR_MINUTES then
      hour = hour + bucket.count
      for key, amount in pairs(bucket.goods) do goods[key] = (goods[key] or 0) + amount end
    end
  end
  out.hour = hour
  local list = {}
  for key, amount in pairs(goods) do
    local kind, name = string.match(tostring(key), "^(%a+)|([^|]+)")
    if kind then list[#list + 1] = { k = kind, n = name, hour = amount } end
  end
  table.sort(list, function(a, b)
    if a.hour ~= b.hour then return a.hour > b.hour end
    return a.n < b.n
  end)
  for i = #list, TOP_GOODS + 1, -1 do
    list[i] = nil
  end
  out.goods = list

  -- Warnungen des Teams: Anzahl der letzten 10 Minuten, die Texte schreibt Output nach utl-alerts.txt
  local alerts = d.alerts[force.name] or {}
  local recent = 0
  for _, a in ipairs(alerts) do
    if game.tick - a.tick < 10 * MINUTE then recent = recent + 1 end
  end
  out.alerts_recent = recent
  out.last_alert = alerts[1] and { tick = alerts[1].tick, icon = alerts[1].icon, group = alerts[1].group } or nil

  -- Anfragen ohne Zug (noch aktuell = in den letzten 3 Minuten gemeldet), älteste zuerst
  local waiting = {}
  for id, u in pairs(d.unserved) do
    if game.tick - u.tick > UNSERVED_TTL then
      d.unserved[id] = nil
    else
      local kind, name = string.match(tostring(u.key), "^(%a+)|([^|]+)")
      waiting[#waiting + 1] = { k = kind, n = name, network = u.network, since = u.since, reason = u.reason }
    end
  end
  table.sort(waiting, function(a, b) return (a.since or 0) < (b.since or 0) end)
  for i = #waiting, 6, -1 do
    waiting[i] = nil
  end
  out.unserved = waiting

  -- Ältere UTL ohne on_alert: Warnungen ersatzweise einmal pro Minute holen
  if not (remote.interfaces["utl"].api_version) and (not d.alerts_poll or game.tick - d.alerts_poll >= MINUTE) then
    d.alerts_poll = game.tick
    local polled = call("get_alerts")
    if type(polled) == "table" and polled[1] then
      out.last_alert = { tick = polled[1].tick, icon = polled[1].icon, group = polled[1].group }
    end
  end
  return out
end

--- Warnungstexte des Teams (neueste zuerst) für utl-alerts.txt.
---@param force LuaForce
function Utl.alerts(force)
  if not Utl.available() then return {} end
  return data().alerts[force.name] or {}
end

--- UTL-Manager für einen Spieler öffnen (optional mit Reiter, z. B. "alerts").
---@param player LuaPlayer
function Utl.open_manager(player, tab)
  if not Utl.available() then return false end
  return call("open_manager", player.index, tab) == true
end

return Utl
