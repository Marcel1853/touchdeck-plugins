local list = {
  {
    type = "int-setting",
    name = "touchdeck-bridge-interval",
    setting_type = "runtime-global",
    default_value = 60,
    minimum_value = 30,
    maximum_value = 600,
    order = "a",
  },
  {
    type = "bool-setting",
    name = "touchdeck-bridge-enabled",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "b",
  },
}
-- Schnell-Chat: leer = übersetzter Standardtext (jeder Mitspieler liest ihn in seiner Sprache).
for i = 1, 6 do
  list[#list + 1] = {
    type = "string-setting",
    name = "touchdeck-bridge-chat-" .. i,
    setting_type = "runtime-per-user",
    default_value = "",
    allow_blank = true,
    order = "c" .. i,
  }
end
data:extend(list)
