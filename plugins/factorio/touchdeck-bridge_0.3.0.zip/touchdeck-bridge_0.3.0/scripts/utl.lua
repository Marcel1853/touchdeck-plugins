-- Optional: Daten aus dem Mod „UTLogistics“ (Unified Train Logistics) über seine Schnittstelle „utl“.
-- Kein Muss: Fehlt der Mod oder eine Funktion, liefert alles nil bzw. „nicht aktiv“, nichts stürzt ab
-- (jeder Aufruf in pcall). Nur lesende Funktionen; alle 10 Sekunden je Team und Fläche neu gelesen.
-- Der Zwischenspeicher betrifft nur die Ausgabe (kein Spielzustand).
local Utl = {}

local MOD = "UTLogistics"
local INTERVAL = 600   -- Ticks
local TOP_GOODS = 8

local cache = {}       -- ["force:surface"] = { tick, data }
local INACTIVE = { tick = 0, data = { active = false } }

function Utl.available()
  return script.active_mods[MOD] ~= nil and remote.interfaces["utl"] ~= nil
end

--- Funktion der Schnittstelle aufrufen; nil, wenn es sie nicht gibt oder sie einen Fehler wirft.
local function call(name, ...)
  local api = remote.interfaces["utl"]
  if not (api and api[name]) then return nil end
  local ok, result = pcall(remote.call, "utl", name, ...)
  if ok then return result end
  return nil
end

local function count(list)
  return type(list) == "table" and #list or nil
end

--- Ware „item|iron-plate|normal“ → k, n (Art und Name) für labels.txt.
local function split_key(key)
  local kind, name = string.match(tostring(key), "^(%a+)|([^|]+)")
  return kind, name
end

local function read(force, surface)
  local data = { active = true, version = script.active_mods[MOD] }
  local filter = { force = force.name }

  local idle = call("get_idle_trains", filter)
  data.idle = count(idle)
  if type(idle) == "table" then
    local here = 0
    for _, t in pairs(idle) do
      if t.surface == surface.index then here = here + 1 end
    end
    data.idle_here = here
  end

  local deliveries = call("get_deliveries")
  data.deliveries = count(deliveries)

  local stations = call("get_stations", filter)
  data.stations = count(stations)
  if type(stations) == "table" then
    local roles = {}
    for _, s in pairs(stations) do
      for role, on in pairs(type(s.roles) == "table" and s.roles or {}) do
        if on then roles[role] = (roles[role] or 0) + 1 end
      end
    end
    data.roles = roles
  end

  data.networks = count(call("get_networks", surface.index, force.name))

  local stats = call("get_statistics")
  if type(stats) == "table" then
    data.total = tonumber(stats.deliveries)
    data.since = tonumber(stats.since)
    local sum, n = 0, 0
    for _, t in pairs(type(stats.trains) == "table" and stats.trains or {}) do
      if type(t.utilization) == "number" then sum, n = sum + t.utilization, n + 1 end
    end
    data.utilization = n > 0 and sum / n or nil
    local goods = {}
    for key, g in pairs(type(stats.goods) == "table" and stats.goods or {}) do
      local kind, name = split_key(key)
      if kind and type(g) == "table" and (tonumber(g.hour) or 0) > 0 then
        goods[#goods + 1] = { k = kind, n = name, hour = tonumber(g.hour), ten = tonumber(g.ten) or 0 }
      end
    end
    table.sort(goods, function(a, b)
      if a.hour ~= b.hour then return a.hour > b.hour end
      return a.n < b.n
    end)
    for i = #goods, TOP_GOODS + 1, -1 do
      goods[i] = nil
    end
    data.goods = goods
  end

  local alerts = call("get_alerts")
  if type(alerts) == "table" then
    local recent = 0
    for _, a in pairs(alerts) do
      if type(a.tick) == "number" and game.tick - a.tick < 36000 then recent = recent + 1 end
    end
    data.alerts = #alerts
    data.alerts_recent = recent   -- letzte 10 Minuten
    local last = alerts[1]
    if type(last) == "table" then
      data.last_alert = { icon = last.icon, group = last.group, count = last.count, tick = last.tick }
    end
  end
  return data
end

--- Daten für Team und Fläche { tick, data } (zwischengespeichert, alle INTERVAL Ticks neu).
---@param force LuaForce
---@param surface LuaSurface
function Utl.read(force, surface)
  if not Utl.available() then
    return INACTIVE
  end
  local id = force.index .. ":" .. surface.index
  local entry = cache[id]
  if not (entry and game.tick - entry.tick < INTERVAL) then
    entry = { tick = game.tick, data = read(force, surface) }
    cache[id] = entry
  end
  return entry
end

--- UTL-Manager für einen Spieler öffnen (optional mit Reiter, z. B. "alerts").
---@param player LuaPlayer
function Utl.open_manager(player, tab)
  if not Utl.available() then return false end
  return call("open_manager", player.index, tab) == true
end

return Utl
