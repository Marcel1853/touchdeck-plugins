# TouchDeck Bridge

Connects **Factorio 2.1** (with or without Space Age) to **TouchDeck**, the macro remote for Linux
that turns a phone or tablet into a control panel. Works together with the TouchDeck plugin
`factorio` (repository `touchdeck-factorio`).

🇩🇪 Deutsche Kurzfassung: siehe unten.

## How it works

- The mod writes `state.json` and `names.txt` to `script-output/touchdeck-bridge/` in your
  Factorio user folder (on Linux `~/.factorio/script-output/`). The TouchDeck plugin watches these
  files.
- Commands come in through the mod's own key bindings (all `Ctrl+Alt+Shift+…`). TouchDeck presses
  them with its built-in “Hotkey” action. Nothing needs to be set up in Factorio: no launch option,
  no RCON, no network.

| Keys (Ctrl+Alt+Shift+…) | Command |
| --- | --- |
| P | Toggle pause |
| 1 / 2 / 3 / 4 | Speed 0.5× / 1× / 2× / 4× |
| N / M | Slower (½) / faster (×2) |
| S | Save (autosave `_autosave-touchdeck`) |
| K | Screenshot to `script-output/touchdeck-bridge/screenshots/` |
| Q / W / E | Queue research suggestion 1 / 2 / 3 (cheapest available research) |
| X | Cancel the current research |
| 5 6 7 8 9 0 | Quick chat 1–6 |
| H | Leave remote view, back to the player |
| U | Write all data again |
| G / A | UTL manager / UTL manager alerts (only with UTLogistics) |
| B | Command field (for typing yourself) |

The keys can be changed in Settings › Controls; then change them in TouchDeck as well.

**Quick chat:** default texts (“Help!”, “On my way!”, “Need iron!”, “Base under attack!”,
“Be right back.”, “Thanks!”) are translated, so every player reads them in their own language.
Own texts: Settings › Mod settings › Per player › Quick chat 1–6.

**Production:** `items.json` lists production and consumption per minute of every item and fluid
that is moving on your surface (updated every 5 seconds); `labels.txt` has their names in your
language. The TouchDeck plugin lets you pick which ones you see.

**Power:** production and consumption of the electric network you stand in (a pole within 32
tiles), the same numbers as the power window, also split by source (steam, turbines, solar,
accumulators, fusion …). No grid nearby → no power value.

**UTLogistics (optional):** if the mod UTLogistics is active, `utl.json` contains idle trains,
running deliveries, stations, networks, total deliveries, train utilization, alerts and the most
delivered goods per hour (read every 10 seconds through its `utl` interface, read-only). Without
UTLogistics the file just says “not active”.

Commands for the command field and `/touchdeck <command>` in the chat (German words work too):
`pause [on|off]`, `speed <number|up|down>`, `save [name]`, `screenshot`, `chat <text>`,
`quickchat <1-6>`, `research <name or #1..#3>`, `cancel`, `center`, `refresh`.

## Multiplayer

- Each player gets the files only on their own computer (`for_player`). The per-player setting
  “Write files for TouchDeck” turns it off.
- Pause, speed and save need admin rights in multiplayer.
- Only the server saves in multiplayer (Factorio rule for `auto_save`).

## Known limits

- **Pause:** while the game is paused (`game.tick_paused`), Factorio runs no timed handlers. The mod
  writes the state at the moment of pausing, so TouchDeck shows “paused”. Resuming works through
  the key binding.
- In the **Esc menu** of a single player game nothing runs: no keys, no files.
- TouchDeck does not type into the command field: with the IBus input method, generated key presses
  do not reach Factorio text fields (tested). Everything TouchDeck does has its own key binding.
- At the start of a game all research is “trigger research” (craft, mine, build …). It cannot be
  queued in labs, so there are no suggestions yet.

## Deutsch

Der Mod schreibt den Spielzustand (inklusive Strom des Netzes, in dem du stehst) nach
`~/.factorio/script-output/touchdeck-bridge/state.json` und nimmt Befehle über eigene
Tastenkürzel (`Strg+Alt+Umschalt+…`, Tabelle oben) an. In Factorio muss nichts eingestellt werden.
Schnell-Chat-Texte lassen sich unter Einstellungen › Mod-Einstellungen › Spieler ändern. Einrichtung
und fertige TouchDeck-Seite: README des Plugins `touchdeck-factorio`.
